SELECT tytul, imie, nazwisko, nazwa FROM ksiazki, autorzy, kategorie WHERE autor = aid and kategoria = kid;

UPDATE autorzy  SET imie="Andrzej", nazwisko = "Nowak" WHERE aid=1;