<?php
    $z = -0220;

    if($z>99 || $z<-99) echo "liczba 3 cyfrowa";
    else echo "nie jest to liczba 3 cyfrowa";