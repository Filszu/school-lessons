<?php
    $x=20;
    $myAge = 16;

    if($x>$myAge) echo "x jest starsza ode mnie";
    else if($x<$myAge) echo "x jest MŁODSZA ode mnie";
    else echo "x ma tyle samo lat co ja";