<?php

    $x = 27;
    $pi = 3.14;
    $tekst = "ćwiczenia PHP";

//27 to liczba pierwsza
// Liczba PI to: 3.14
// ćwiczenia PHP są super

echo "$x to liczba pierwsza<br>
Liczba PI to: $pi<br>
$tekst są super";
