<?php

// Wyświetl wynik dodawania, odejmowania, dzielenia, mnożenia, reszty z dzielenia i potęgowania dwóch
// zmiennych:

$x = 4;
$y = 8;

echo "dodawanie: ";
echo $x+$y;
echo "<br>odejmowanie: ";
echo $x-$y;
echo "<br>dzielenie: ";
echo $x/$y;
echo "<br>dzielenie: ";
echo $y/$x;
echo "<br>mnzoenie: ";
echo $x*$y;
echo "<br>y%x: ";
echo $y%$x;
echo "<br>x^y: ";
echo pow($x,$y);



