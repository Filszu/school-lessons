### Sprawdzian

## LVL 1
    Utwórz program obliczający objętość walca
    Wynik zaokrąglij

## LVL2
    Utwórz program sprawdzjący liczby od 1-100 czy są podzielne przez 3

## LVL3

    Użyj pętli, aby wyświtlić poniższy rysunek na stronie
    *****#
    ****#
    ***#
    **#
    *#
    #



## LVL 4

Utwórz tablicę $students,
zawierającą imiona, 
posortuj według imion,
i wyświetl ją za pomocą pętli na stronie.



Wynik końcowy:
    Filip
    Irwin
    leon
    Natan


## LVL 5

Zmodyfikuj cwiczenie 4

Utwórz tablicę $students,
zawierającą imiona uczniów ich klasy, 

i wyświetl ją za pomocą pętli na stronie.




Wynik końcowy:
    Filip 3
    Irwin 3
    leon 2
    Natan 3


// 5 podpowiedzi do 5

$students = array();
$student1 = array("name"=>"Filip", "age"=>17, "class"=>"3Td");
array_push($students, $newStudent);


    