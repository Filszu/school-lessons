<?php

// 
$PI = 3.14;
$r = 5;
$h= 10;

$v = $PI*($r**2)*$h;

echo "V walca: $h";


echo "<hr>";

// 2

for($i=0;$i<=10;$i++){
    if($i%3==0){
        echo"$i jest podzielne przez 3<br/>";
    }
    else{
        echo "$i jest niepodzielne przez 3<br/>";
    }
    
}

echo "<hr>";

// 3
$i=6;
// $rows = 6;
for($i; $i>0; $i--){
    for($j=1; $j<$i; $j++){
        echo "*";
    }
    echo "#";
    echo"<br>";
   

}


// 5 podpowiedzi do 5

$students = array();
$student1 = array("name"=>"Filip", "age"=>17, "class"=>"3Td");
array_push($students, $newStudent);


