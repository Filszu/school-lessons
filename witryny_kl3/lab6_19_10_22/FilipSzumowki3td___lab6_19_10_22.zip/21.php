<?php
    function pokazImie($imie){
        echo $imie;
    }

    pokazImie("Filip");
    // pokazImie("Waciakol");