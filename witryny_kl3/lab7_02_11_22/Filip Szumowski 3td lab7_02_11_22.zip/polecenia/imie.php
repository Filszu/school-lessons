<?php
$imie = @$_POST['nazwa'] ;

echo "Witaj $imie miło Mi Ciebie poznać";

?>