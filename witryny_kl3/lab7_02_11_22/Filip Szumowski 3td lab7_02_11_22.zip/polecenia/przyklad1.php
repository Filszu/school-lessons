<!DOCTYPE html>
<html>
<body>
<p>Podaj swoje imię:</p>
<form action="imie.php" method="post">
	<input name="nazwa" type="text" />
	<input type="submit" />
</form>

</body>
</html>