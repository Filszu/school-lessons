<?php
for($i=10; $i>=0; $i--){
    echo $i."<br>";
}