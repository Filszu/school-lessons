<?php

$i=2;
$rows = 6;
for($i; $i<=$rows; $i++){
    for($j=1; $j<$i; $j++){
        echo "*";
    }
    echo"<br>";
   

}